import type { Metadata } from "next";
import Link from "next/link";
import Container from "@/components/shared/Container";
import ConsultationFaqAccordion from "@/components/services/physician-consultation/ConsultationFaqAccordion";

export const metadata: Metadata = {
  title: "Physician Consultation FAQs | Sutra Health",
  description: "Answers about preparing for a physician consultation, appointment options, donation information and medical care at Sutra Health.",
  alternates: { canonical: "https://lifequality.org.in/services/physician-consultation/faqs" },
  robots: { index: true, follow: true },
  openGraph: {
    title: "Physician Consultation FAQs | Sutra Health",
    description: "Answers about preparing for a physician consultation, appointment options, donation information and medical care at Sutra Health.",
    url: "https://lifequality.org.in/services/physician-consultation/faqs",
    siteName: "Sutra Health", type: "article", locale: "en_IN",
  },
};

const faqs = [
  { question: "What should I bring to my consultation?", answer: "Bring relevant medical reports, a list of your current medicines and notes about your main concerns or questions. Check whether the appointment provider has any additional preparation instructions." },
  { question: "Can I discuss an existing health condition?", answer: "You can explain your concerns and medical history. The clinician will determine what can be assessed during the appointment and whether additional evaluation or referral is appropriate." },
  { question: "Is online consultation available?", answer: "The previous website linked to a Lybrate profile for Dr. Rakesh Sarwal. Check the profile for current availability and appointment terms.", link: { label: "View Dr. Rakesh Sarwal’s profile", href: "https://www.lybrate.com/faridabad/doctor/dr-rakesh-sarwal-preventive-medicine-specialist" } },
  { question: "What is the consultation donation?", answer: "The legacy page listed a suggested donation of ₹100 per consultation. Confirm the current amount and arrangement directly with the provider before booking." },
  { question: "Can lifestyle approaches replace prescribed medicine?", answer: "No. Lifestyle practices may complement appropriate care, but they should not replace prescribed treatment. Speak with your treating clinician before stopping or changing any medicine." },
  { question: "Will I receive a diagnosis at every appointment?", answer: "Not necessarily. The next steps depend on your concern, the available information and the clinical assessment. Further tests, examination or referral may be needed." },
  { question: "Are the health awareness tools diagnostic?", answer: "No. Tools referenced by the previous website are intended for awareness or measurement exploration. They do not replace a clinical assessment or provide a medical diagnosis." },
  { question: "Can I use ABHA instead of booking a consultation?", answer: "No. ABHA is a digital health identity used by participating digital health services. It is not a physician appointment and does not provide a diagnosis.", link: { label: "Visit the official ABHA portal", href: "https://abha.abdm.gov.in/abha/v3" } },
];

export default function ConsultationFaqsPage() {
  return (
    <main className="bg-[var(--sutra-porcelain)] text-[var(--sutra-ink)]">
      <section className="border-b border-[var(--sutra-border)] bg-white">
        <Container><div className="max-w-4xl py-12 sm:py-16 lg:py-20">
          
          <p className="text-sm font-semibold uppercase tracking-[0.18em] text-[var(--sutra-teal)]">Patient information</p>
          <h1 className="mt-4 max-w-4xl font-serif text-4xl leading-[1.12] tracking-[-0.035em] sm:text-5xl lg:text-6xl">Frequently asked questions</h1>
          <p className="mt-6 max-w-3xl text-lg leading-8 text-[var(--sutra-muted)] sm:text-xl sm:leading-9">Practical answers about preparing for a consultation, appointment arrangements and what to expect from care.</p>
        </div></Container>
      </section>
      <section className="py-12 sm:py-16 lg:py-20"><Container><div className="max-w-4xl">
        <h2 className="font-serif text-3xl leading-tight tracking-[-0.025em] sm:text-4xl">Your questions, answered</h2>
        <p className="mt-3 mb-8 text-lg leading-8 text-[var(--sutra-muted)]">Select a question to read the answer.</p>
        <ConsultationFaqAccordion items={faqs} />
        <p className="mt-8 text-base leading-8 text-[var(--sutra-muted)]">These answers are general information, not personalised medical advice. Confirm current booking arrangements, donation information and service availability with the provider. Do not delay urgent medical care while seeking information online.</p>
        <div className="mt-12 flex flex-col gap-3 border-t border-[var(--sutra-border)] pt-8 sm:flex-row sm:flex-wrap">
          <Link href="/services/physician-consultation" className="inline-flex min-h-12 items-center justify-center border border-[var(--sutra-border-strong)] px-6 py-3 text-base font-bold text-[var(--sutra-teal)] transition-colors hover:bg-white">← Back to Physician Consultation</Link>
          <Link href="/book-appointment" className="inline-flex min-h-12 items-center justify-center bg-[var(--sutra-teal)] px-6 py-3 text-base font-bold text-white transition-opacity hover:opacity-90">Book a Consultation ↗</Link>
        </div>
      </div></Container></section>
    </main>
  );
}
