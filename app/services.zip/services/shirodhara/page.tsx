import type { Metadata } from "next";
import Link from "next/link";
import Container from "@/components/shared/Container";

const SITE_URL = "https://lifequality.org.in";
const PAGE_URL = `${SITE_URL}/services/shirodhara`;

export const metadata: Metadata = {
  title: "Shirodhara & Abhyanga Massage in Faridabad | Sutra Health",
  description:
    "Explore traditional Shirodhara and Abhyanga massage at Sutra Health in Faridabad, including what each practice involves and how to enquire about a session.",
  alternates: { canonical: PAGE_URL },
  robots: { index: true, follow: true },
  openGraph: {
    title: "Shirodhara & Abhyanga Massage | Sutra Health",
    description:
      "A concise guide to traditional Shirodhara and Abhyanga wellness practices at Sutra Health in Faridabad.",
    url: PAGE_URL,
    siteName: "Sutra Health",
    type: "website",
    locale: "en_IN",
    images: [{ url: `${SITE_URL}/images/image8.png`, alt: "Traditional wellness therapy at Life Quality" }],
  },
};

const schema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "@id": `${PAGE_URL}#webpage`,
  url: PAGE_URL,
  name: "Shirodhara & Abhyanga Massage | Sutra Health",
  description: String(metadata.description),
  inLanguage: "en-IN",
  isPartOf: { "@type": "WebSite", name: "Sutra Health", url: `${SITE_URL}/` },
};

const pages = [
  {
    number: "01",
    title: "Shirodhara Therapy",
    description: "Understand the traditional practice, how a session may be conducted and what to discuss before booking.",
    href: "/services/shirodhara/shirodhara-therapy",
    link: "Explore Shirodhara",
  },
  {
    number: "02",
    title: "Abhyanga Oil Massage",
    description: "Learn about the traditional oil massage practice and the kind of experience it is intended to offer.",
    href: "/services/shirodhara/abhyanga-massage",
    link: "Explore Abhyanga",
  },
  {
    number: "03",
    title: "Before You Book",
    description: "Know what to ask, share relevant health information and discuss whether a session is suitable for you.",
    href: "/services/shirodhara/what-to-expect",
    link: "What to expect",
  },
];

export default function ShirodharaOverviewPage() {
  return (
    <main className="overflow-hidden bg-[var(--sutra-porcelain)] text-[var(--sutra-ink)]">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />

      <section aria-labelledby="shirodhara-title" className="border-b border-[var(--sutra-border)] bg-[#173B36]">
        <Container>
          <div className="grid items-center gap-10 py-14 sm:py-18 lg:grid-cols-[1.08fr_0.92fr] lg:gap-16 lg:py-24">
            <div className="relative z-10">
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#D8C99F] sm:text-xs">Traditional wellness practices · Faridabad</p>
              <h1 id="shirodhara-title" className="mt-5 max-w-3xl font-serif text-[clamp(2.6rem,5.6vw,4.8rem)] leading-[1.04] tracking-[-0.04em] text-white">
                Explore Shirodhara and Abhyanga.
              </h1>
              <p className="mt-6 max-w-2xl text-base leading-8 text-white/80 sm:text-lg sm:leading-9">
                Shirodhara and Abhyanga are traditional Ayurvedic wellness practices that use a gentle, considered approach to relaxation. Learn what each involves and speak with the team about suitability before arranging a session.
              </p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
                <Link href="/book-appointment" className="inline-flex min-h-12 items-center justify-center gap-3 bg-[#F7F5EF] px-6 py-3 text-sm font-bold text-[#17413D] transition-colors hover:bg-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-white">
                  Enquire About a Session <span aria-hidden="true">↗</span>
                </Link>
                <Link href="#explore-therapies" className="inline-flex min-h-12 items-center justify-center gap-3 border border-white/45 px-6 py-3 text-sm font-bold text-white transition-colors hover:bg-white/10 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-white">
                  Explore the practices <span aria-hidden="true">↓</span>
                </Link>
              </div>
              <p className="mt-5 max-w-xl text-xs leading-6 text-white/65">These are traditional wellness practices, not substitutes for medical assessment or prescribed treatment.</p>
            </div>

            <aside className="border border-white/20 bg-white/[0.06] p-7 sm:p-9" aria-label="Session overview">
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#D8C99F]">Before you enquire</p>
              <h2 className="mt-4 font-serif text-2xl leading-tight text-white sm:text-3xl">Understand the practice first.</h2>
              <p className="mt-4 text-sm leading-7 text-white/75">Ask about the session steps, materials, expected duration and any precautions relevant to you. The provider can explain what is offered and help you decide what questions to raise.</p>
              <Link href="/services/shirodhara/what-to-expect" className="mt-5 inline-flex items-center gap-2 text-sm font-bold text-white underline decoration-white/40 underline-offset-4 hover:decoration-white">Read before booking <span aria-hidden="true">↗</span></Link>
            </aside>
          </div>
        </Container>
      </section>

      <section id="explore-therapies" aria-labelledby="overview-title" className="bg-white">
        <Container>
          <div className="grid gap-6 py-14 sm:py-18 lg:grid-cols-[0.8fr_1.2fr] lg:gap-20 lg:py-20">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--sutra-teal)] sm:text-xs">The overview</p>
              <h2 id="overview-title" className="mt-4 max-w-lg font-serif text-3xl leading-[1.12] tracking-[-0.03em] sm:text-4xl lg:text-5xl">Two traditional practices, with different approaches.</h2>
            </div>
            <div className="max-w-3xl">
              <p className="text-base leading-8 text-[var(--sutra-muted)] sm:text-lg sm:leading-9">
                Shirodhara involves a steady stream of liquid, traditionally oil, directed across the forehead while a person rests. Abhyanga is a traditional oil massage. The materials and session approach may vary, so ask the team what is offered and whether it is appropriate for your circumstances.
              </p>
              <p className="mt-4 text-base leading-8 text-[var(--sutra-muted)] sm:text-lg sm:leading-9">
                Explore each practice below for more detail. Claims about detoxification, disease treatment or specific effects on the nervous system should not be assumed from the traditional description alone.
              </p>
            </div>
          </div>
        </Container>
      </section>

      <section className="bg-[var(--sutra-porcelain)]">
        <Container>
          <div className="py-14 sm:py-18 lg:py-20">
            <div className="max-w-2xl">
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--sutra-teal)] sm:text-xs">Explore the guides</p>
              <h2 className="mt-4 font-serif text-3xl leading-tight tracking-[-0.03em] sm:text-4xl">Find the information you need.</h2>
            </div>
            <div className="mt-9 grid gap-5 md:grid-cols-3">
              {pages.map((page) => (
                <article key={page.href} className="border border-[var(--sutra-border)] bg-white">
                  <div className="p-6 sm:p-7">
                    <p className="text-xs font-semibold tracking-[0.16em] text-[var(--sutra-teal)]">{page.number}</p>
                    <h3 className="mt-3 font-serif text-2xl leading-tight">{page.title}</h3>
                    <p className="mt-3 text-sm leading-7 text-[var(--sutra-muted)]">{page.description}</p>
                    <Link href={page.href} className="mt-5 inline-flex items-center gap-2 text-sm font-bold text-[var(--sutra-teal)] underline decoration-[var(--sutra-border)] underline-offset-4 hover:decoration-current">
                      {page.link} <span aria-hidden="true">↗</span>
                    </Link>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </Container>
      </section>

      <section aria-labelledby="shirodhara-gallery-title" className="bg-white">
        <Container>
          <div className="py-14 sm:py-16 lg:py-20">
            <div className="max-w-2xl">
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--sutra-teal)]">Original Life Quality gallery</p>
              <h2 id="shirodhara-gallery-title" className="mt-4 font-serif text-3xl leading-tight tracking-[-0.03em] sm:text-4xl">From the previous website gallery.</h2>
              <p className="mt-4 text-sm leading-7 text-[var(--sutra-muted)]">These archival images are grouped here as visual references. They are not presented as evidence of treatment effects or outcomes.</p>
            </div>
            <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              <figure className="overflow-hidden border border-[var(--sutra-border)] bg-[var(--sutra-porcelain)]"><div className="aspect-[5/4] overflow-hidden"><img src="https://lifequality.org.in/images/image8.png" alt="Shirodhara session pictured on the former Life Quality website" className="h-full w-full object-cover" width="600" height="480" loading="lazy" /></div><figcaption className="px-4 py-3 text-sm leading-6 text-[var(--sutra-muted)]">Shirodhara session shown in the original gallery.</figcaption></figure>
              <figure className="overflow-hidden border border-[var(--sutra-border)] bg-[var(--sutra-porcelain)]"><div className="aspect-[5/4] overflow-hidden"><img src="https://lifequality.org.in/images/1img.jpg" alt="Abhyanga massage pictured on the former Life Quality website" className="h-full w-full object-cover" width="600" height="480" loading="lazy" /></div><figcaption className="px-4 py-3 text-sm leading-6 text-[var(--sutra-muted)]">Traditional massage shown in the original gallery.</figcaption></figure>
              <figure className="overflow-hidden border border-[var(--sutra-border)] bg-[var(--sutra-porcelain)]"><div className="aspect-[5/4] overflow-hidden"><img src="https://lifequality.org.in/images/leg.jpg" alt="Leg and foot massage pictured on the former Life Quality website" className="h-full w-full object-cover" width="600" height="480" loading="lazy" /></div><figcaption className="px-4 py-3 text-sm leading-6 text-[var(--sutra-muted)]">Leg and foot massage from the original gallery.</figcaption></figure>
            </div>
          </div>
        </Container>
      </section>

      <section className="bg-white">
        <Container>
          <div className="grid gap-6 py-14 sm:py-16 lg:grid-cols-[0.8fr_1.2fr] lg:gap-20">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--sutra-teal)]">A note on suitability</p>
              <h2 className="mt-4 font-serif text-3xl leading-tight tracking-[-0.03em] sm:text-4xl">Discuss your needs before a session.</h2>
            </div>
            <div className="max-w-3xl">
              <p className="text-base leading-8 text-[var(--sutra-muted)]">
                Tell the provider about relevant health conditions, allergies, skin sensitivity, pregnancy, recent procedures or any concern that could affect the session. Ask about the materials used and any precautions. If you are seeking help for a symptom or medical condition, consult a qualified healthcare professional rather than relying on a wellness therapy alone.
              </p>
              <Link href="/book-appointment" className="mt-6 inline-flex min-h-12 items-center justify-center gap-3 bg-[#173B36] px-6 py-3 text-sm font-bold text-white transition-colors hover:bg-[#24554d]">
                Contact Sutra Health <span aria-hidden="true">↗</span>
              </Link>
            </div>
          </div>
        </Container>
      </section>
    </main>
  );
}
