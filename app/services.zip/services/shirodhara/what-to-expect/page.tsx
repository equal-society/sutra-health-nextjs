import type { Metadata } from "next";
import Link from "next/link";
import Container from "@/components/shared/Container";

const SITE_URL = "https://lifequality.org.in";
const PAGE_URL = `${SITE_URL}/services/shirodhara/what-to-expect`;

export const metadata: Metadata = {
  title: "Before a Shirodhara or Abhyanga Session | Sutra Health",
  description: "Prepare for a traditional wellness session by asking about the process, materials, duration and precautions before booking.",
  alternates: { canonical: PAGE_URL },
  robots: { index: true, follow: true },
  openGraph: {
    title: "Before a Shirodhara or Abhyanga Session | Sutra Health",
    description: "Prepare for a traditional wellness session by asking about the process, materials, duration and precautions before booking.",
    url: PAGE_URL,
    siteName: "Sutra Health",
    type: "article",
    locale: "en_IN",
  },
};

const schema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "@id": "https://lifequality.org.in/services/shirodhara/what-to-expect#webpage",
  "url": "https://lifequality.org.in/services/shirodhara/what-to-expect",
  "name": "Before a Shirodhara or Abhyanga Session | Sutra Health",
  "description": "A little preparation can help you understand the session, ask relevant questions and discuss whether the practice is appropriate for you. Confirm the exact service, materials, session process and any precautions directly with Sutra Health before booking.",
  "inLanguage": "en-IN",
  "isPartOf": {
    "@type": "WebSite",
    "name": "Sutra Health",
    "url": "https://lifequality.org.in/"
  }
};

export default function WhatToExpectPage() {
  return (
    <main className="overflow-hidden bg-[var(--sutra-porcelain)] text-[var(--sutra-ink)]">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />
      <section aria-labelledby="page-title" className="bg-[#173B36]">
        <Container>
          <div className="grid items-center gap-9 py-12 sm:py-16 lg:grid-cols-[1fr_0.8fr] lg:gap-16 lg:py-20">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#D8C99F]">Traditional wellness practices · Faridabad</p>
              <h1 id="page-title" className="mt-5 max-w-3xl font-serif text-[clamp(2.5rem,5vw,4.5rem)] leading-[1.05] tracking-[-0.04em] text-white">Before you book a traditional wellness session</h1>
              <p className="mt-6 max-w-2xl text-base leading-8 text-white/80 sm:text-lg sm:leading-9">A little preparation can help you understand the session, ask relevant questions and discuss whether the practice is appropriate for you. Confirm the exact service, materials, session process and any precautions directly with Sutra Health before booking.</p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <Link href="/book-appointment" className="inline-flex min-h-12 items-center justify-center bg-[#F7F5EF] px-6 py-3 text-sm font-bold text-[#17413D] hover:bg-white">Enquire About a Session <span className="ml-2" aria-hidden="true">↗</span></Link>
                <Link href="/services/shirodhara" className="inline-flex min-h-12 items-center justify-center border border-white/45 px-6 py-3 text-sm font-bold text-white hover:bg-white/10">Back to overview</Link>
              </div>
            </div>
            <aside className="border border-white/20 bg-white/[0.06] p-7 sm:p-9" aria-label="Session overview">
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#D8C99F]">Before you enquire</p>
              <h2 className="mt-4 font-serif text-2xl leading-tight text-white sm:text-3xl">Know what to confirm beforehand.</h2>
              <p className="mt-4 text-sm leading-7 text-white/75">Confirm the service, materials, duration, preparation and precautions. Share relevant health information and ask questions before deciding.</p>
              <Link href="/services/shirodhara/what-to-expect" className="mt-5 inline-flex items-center gap-2 text-sm font-bold text-white underline decoration-white/40 underline-offset-4 hover:decoration-white">Read before booking <span aria-hidden="true">↗</span></Link>
            </aside>
          </div>
        </Container>
      </section>
              <section aria-labelledby="section-0" className="bg-[var(--sutra-porcelain)]">
          <Container>
            <div className="grid gap-6 py-12 sm:py-16 lg:grid-cols-[0.8fr_1.2fr] lg:gap-20 lg:py-20">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--sutra-teal)]">THE PRACTICE</p>
                <h2 id="section-0" className="mt-4 font-serif text-3xl leading-tight tracking-[-0.03em] sm:text-4xl">Questions to ask</h2>
              </div>
              <p className="max-w-3xl text-base leading-8 text-[var(--sutra-muted)] sm:text-lg sm:leading-9">Ask which practice is planned, what materials will be used, how long the session usually takes, what clothing or preparation is needed, and how to communicate discomfort during the session.</p>
            </div>
          </Container>
        </section>
        <section aria-labelledby="section-1" className="bg-white">
          <Container>
            <div className="grid gap-6 py-12 sm:py-16 lg:grid-cols-[0.8fr_1.2fr] lg:gap-20 lg:py-20">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--sutra-teal)]">DETAILS</p>
                <h2 id="section-1" className="mt-4 font-serif text-3xl leading-tight tracking-[-0.03em] sm:text-4xl">Information to share</h2>
              </div>
              <p className="max-w-3xl text-base leading-8 text-[var(--sutra-muted)] sm:text-lg sm:leading-9">Tell the provider about relevant health conditions, allergies, skin sensitivity, pregnancy, recent surgery or procedures, and medicines or symptoms that may be relevant. If unsure whether a session is suitable, seek advice from a qualified healthcare professional first.</p>
            </div>
          </Container>
        </section>
        <section aria-labelledby="section-2" className="bg-[var(--sutra-porcelain)]">
          <Container>
            <div className="grid gap-6 py-12 sm:py-16 lg:grid-cols-[0.8fr_1.2fr] lg:gap-20 lg:py-20">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--sutra-teal)]">DETAILS</p>
                <h2 id="section-2" className="mt-4 font-serif text-3xl leading-tight tracking-[-0.03em] sm:text-4xl">During and after the session</h2>
              </div>
              <p className="max-w-3xl text-base leading-8 text-[var(--sutra-muted)] sm:text-lg sm:leading-9">You should be able to ask questions, raise concerns and request that the session pause or stop. Follow the provider's practical aftercare instructions, and seek medical advice if you experience a concerning reaction or symptom.</p>
            </div>
          </Container>
        </section>
      <section aria-labelledby="gallery-title" className="bg-white">
        <Container>
          <div className="py-12 sm:py-16 lg:py-20">
            <div className="max-w-2xl">
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--sutra-teal)]">Original Life Quality images</p>
              <h2 id="gallery-title" className="mt-4 font-serif text-3xl leading-tight tracking-[-0.03em] sm:text-4xl">Images from the previous website</h2>
              <p className="mt-4 max-w-2xl text-sm leading-7 text-[var(--sutra-muted)]">These images are presented together as a gallery from the previous website, not as claims about outcomes or guaranteed effects.</p>
            </div>
            <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                            <figure className="overflow-hidden border border-[var(--sutra-border)] bg-[var(--sutra-porcelain)]">
                <div className="aspect-[5/4] overflow-hidden bg-[#e5e8df]"><img src="https://lifequality.org.in/images/image9.png" alt="Massage therapy room shown on the former Life Quality website" className="h-full w-full object-cover" width="600" height="480" loading="lazy" /></div>
                <figcaption className="px-4 py-3 text-sm leading-6 text-[var(--sutra-muted)]">Massage therapy room shown in the original gallery.</figcaption>
              </figure>
              <figure className="overflow-hidden border border-[var(--sutra-border)] bg-[var(--sutra-porcelain)]">
                <div className="aspect-[5/4] overflow-hidden bg-[#e5e8df]"><img src="https://lifequality.org.in/images/2img.jpg" alt="Warm oil preparation shown on the former Life Quality website" className="h-full w-full object-cover" width="600" height="480" loading="lazy" /></div>
                <figcaption className="px-4 py-3 text-sm leading-6 text-[var(--sutra-muted)]">Warm oil preparation shown in the original gallery.</figcaption>
              </figure>
              <figure className="overflow-hidden border border-[var(--sutra-border)] bg-[var(--sutra-porcelain)]">
                <div className="aspect-[5/4] overflow-hidden bg-[#e5e8df]"><img src="https://lifequality.org.in/images/4img.jpg" alt="Person relaxing during a traditional wellness session" className="h-full w-full object-cover" width="600" height="480" loading="lazy" /></div>
                <figcaption className="px-4 py-3 text-sm leading-6 text-[var(--sutra-muted)]">Person relaxing during a traditional wellness session.</figcaption>
              </figure>
            </div>
          </div>
        </Container>
      </section>

      <section className="bg-white">
        <Container>
          <div className="py-12 sm:py-16 lg:py-20">
            <div className="max-w-2xl">
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--sutra-teal)]">Common questions</p>
              <h2 className="mt-4 font-serif text-3xl leading-tight tracking-[-0.03em] sm:text-4xl">Before you decide</h2>
            </div>
            <div className="mt-6 max-w-4xl">          <details className="group border-b border-[var(--sutra-border)] py-5">
            <summary className="cursor-pointer list-none pr-8 text-base font-semibold text-[var(--sutra-ink)] marker:content-none">Do I need to prepare before the session?<span className="float-right text-[var(--sutra-teal)] transition-transform group-open:rotate-45">+</span></summary>
            <p className="mt-3 max-w-3xl text-sm leading-7 text-[var(--sutra-muted)]">Preparation can vary by practice and provider. Confirm instructions, clothing and timing when enquiring.</p>
          </details>
          <details className="group border-b border-[var(--sutra-border)] py-5">
            <summary className="cursor-pointer list-none pr-8 text-base font-semibold text-[var(--sutra-ink)] marker:content-none">What if I am booking because of a health problem?<span className="float-right text-[var(--sutra-teal)] transition-transform group-open:rotate-45">+</span></summary>
            <p className="mt-3 max-w-3xl text-sm leading-7 text-[var(--sutra-muted)]">Discuss the concern with a qualified healthcare professional. A traditional wellness session should not delay medical assessment or replace prescribed treatment.</p>
          </details></div>
            <p className="mt-8 max-w-3xl text-sm leading-7 text-[var(--sutra-muted)]">This information describes traditional wellness practices and is not a diagnosis or treatment recommendation. Discuss individual health concerns with a qualified healthcare professional.</p>
            <Link href="/book-appointment" className="mt-6 inline-flex min-h-12 items-center justify-center bg-[#173B36] px-6 py-3 text-sm font-bold text-white hover:bg-[#24554d]">Contact Sutra Health <span className="ml-2" aria-hidden="true">↗</span></Link>
          </div>
        </Container>
      </section>
    </main>
  );
}
