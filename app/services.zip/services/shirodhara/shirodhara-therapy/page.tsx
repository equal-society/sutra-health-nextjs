import type { Metadata } from "next";
import Link from "next/link";
import Container from "@/components/shared/Container";

const SITE_URL = "https://lifequality.org.in";
const PAGE_URL = `${SITE_URL}/services/shirodhara/shirodhara-therapy`;

export const metadata: Metadata = {
  title: "Shirodhara Therapy in Faridabad | Sutra Health",
  description: "Shirodhara is a traditional Ayurvedic wellness practice involving a steady stream of liquid across the forehead while a person rests.",
  alternates: { canonical: PAGE_URL },
  robots: { index: true, follow: true },
  openGraph: {
    title: "Shirodhara Therapy in Faridabad | Sutra Health",
    description: "Shirodhara is a traditional Ayurvedic wellness practice involving a steady stream of liquid across the forehead while a person rests.",
    url: PAGE_URL,
    siteName: "Sutra Health",
    type: "article",
    locale: "en_IN",
  },
};

const schema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "@id": "https://lifequality.org.in/services/shirodhara/shirodhara-therapy#webpage",
  "url": "https://lifequality.org.in/services/shirodhara/shirodhara-therapy",
  "name": "Shirodhara Therapy in Faridabad | Sutra Health",
  "description": "Shirodhara is a traditional Ayurvedic wellness practice in which a steady stream of liquid is directed across the forehead while the person rests. Traditionally, the liquid may be oil or another preparation selected for the session. The method and materials should be discussed with the provider before a session.",
  "inLanguage": "en-IN",
  "isPartOf": {
    "@type": "WebSite",
    "name": "Sutra Health",
    "url": "https://lifequality.org.in/"
  }
};

export default function ShirodharaTherapyPage() {
  return (
    <main className="overflow-hidden bg-[var(--sutra-porcelain)] text-[var(--sutra-ink)]">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />
      <section aria-labelledby="page-title" className="bg-[#173B36]">
        <Container>
          <div className="grid items-center gap-9 py-12 sm:py-16 lg:grid-cols-[1fr_0.8fr] lg:gap-16 lg:py-20">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#D8C99F]">Traditional wellness practices · Faridabad</p>
              <h1 id="page-title" className="mt-5 max-w-3xl font-serif text-[clamp(2.5rem,5vw,4.5rem)] leading-[1.05] tracking-[-0.04em] text-white">Understanding Shirodhara therapy</h1>
              <p className="mt-6 max-w-2xl text-base leading-8 text-white/80 sm:text-lg sm:leading-9">Shirodhara is a traditional Ayurvedic wellness practice in which a steady stream of liquid is directed across the forehead while the person rests. Traditionally, the liquid may be oil or another preparation selected for the session. The method and materials should be discussed with the provider before a session.</p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <Link href="/book-appointment" className="inline-flex min-h-12 items-center justify-center bg-[#F7F5EF] px-6 py-3 text-sm font-bold text-[#17413D] hover:bg-white">Enquire About a Session <span className="ml-2" aria-hidden="true">↗</span></Link>
                <Link href="/services/shirodhara" className="inline-flex min-h-12 items-center justify-center border border-white/45 px-6 py-3 text-sm font-bold text-white hover:bg-white/10">Back to overview</Link>
              </div>
            </div>
            <aside className="border border-white/20 bg-white/[0.06] p-7 sm:p-9" aria-label="Session overview">
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#D8C99F]">Before you enquire</p>
              <h2 className="mt-4 font-serif text-2xl leading-tight text-white sm:text-3xl">Know how the session works.</h2>
              <p className="mt-4 text-sm leading-7 text-white/75">Ask how the liquid is selected and applied, how long the session may take, and how comfort is checked throughout.</p>
              <Link href="/services/shirodhara/what-to-expect" className="mt-5 inline-flex items-center gap-2 text-sm font-bold text-white underline decoration-white/40 underline-offset-4 hover:decoration-white">Read before booking <span aria-hidden="true">↗</span></Link>
            </aside>
          </div>
        </Container>
      </section>
              <section aria-labelledby="section-0" className="bg-[var(--sutra-porcelain)]">
          <Container>
            <div className="grid gap-6 py-12 sm:py-16 lg:grid-cols-[0.8fr_1.2fr] lg:gap-20 lg:py-20">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--sutra-teal)]">THE PRACTICE</p>
                <h2 id="section-0" className="mt-4 font-serif text-3xl leading-tight tracking-[-0.03em] sm:text-4xl">What the practice involves</h2>
              </div>
              <p className="max-w-3xl text-base leading-8 text-[var(--sutra-muted)] sm:text-lg sm:leading-9">The person rests in a supported position while a controlled stream of liquid is directed across the forehead. The setup, duration and materials can vary. Ask the provider to explain the planned session, how comfort is monitored and how you can pause or stop if needed.</p>
            </div>
          </Container>
        </section>
        <section aria-labelledby="section-1" className="bg-white">
          <Container>
            <div className="grid gap-6 py-12 sm:py-16 lg:grid-cols-[0.8fr_1.2fr] lg:gap-20 lg:py-20">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--sutra-teal)]">DETAILS</p>
                <h2 id="section-1" className="mt-4 font-serif text-3xl leading-tight tracking-[-0.03em] sm:text-4xl">What to discuss beforehand</h2>
              </div>
              <p className="max-w-3xl text-base leading-8 text-[var(--sutra-muted)] sm:text-lg sm:leading-9">Share relevant health conditions, allergies, skin sensitivity, pregnancy, recent procedures and any symptoms you are seeking help for. Ask which oils or other materials will be used and whether any precautions apply to you.</p>
            </div>
          </Container>
        </section>
        <section aria-labelledby="section-2" className="bg-[var(--sutra-porcelain)]">
          <Container>
            <div className="grid gap-6 py-12 sm:py-16 lg:grid-cols-[0.8fr_1.2fr] lg:gap-20 lg:py-20">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--sutra-teal)]">DETAILS</p>
                <h2 id="section-2" className="mt-4 font-serif text-3xl leading-tight tracking-[-0.03em] sm:text-4xl">What to expect</h2>
              </div>
              <p className="max-w-3xl text-base leading-8 text-[var(--sutra-muted)] sm:text-lg sm:leading-9">The session is intended as a traditional relaxation and wellness experience. Individual experiences vary, and it should not be presented as a proven treatment for a medical condition or as a replacement for appropriate healthcare.</p>
            </div>
          </Container>
        </section>
      <section aria-labelledby="gallery-title" className="bg-white">
        <Container>
          <div className="py-12 sm:py-16 lg:py-20">
            <div className="max-w-2xl">
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--sutra-teal)]">Original Life Quality images</p>
              <h2 id="gallery-title" className="mt-4 font-serif text-3xl leading-tight tracking-[-0.03em] sm:text-4xl">Shirodhara in the original gallery</h2>
              <p className="mt-4 max-w-2xl text-sm leading-7 text-[var(--sutra-muted)]">These images are presented together as a gallery from the previous website, not as claims about outcomes or guaranteed effects.</p>
            </div>
            <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                            <figure className="overflow-hidden border border-[var(--sutra-border)] bg-[var(--sutra-porcelain)]">
                <div className="aspect-[5/4] overflow-hidden bg-[#e5e8df]"><img src="https://lifequality.org.in/images/image8.png" alt="Traditional Shirodhara session" className="h-full w-full object-cover" width="600" height="480" loading="lazy" /></div>
                <figcaption className="px-4 py-3 text-sm leading-6 text-[var(--sutra-muted)]">Shirodhara session shown in the original gallery.</figcaption>
              </figure>
              <figure className="overflow-hidden border border-[var(--sutra-border)] bg-[var(--sutra-porcelain)]">
                <div className="aspect-[5/4] overflow-hidden bg-[#e5e8df]"><img src="https://lifequality.org.in/images/image9.png" alt="Massage therapy room shown on the former Life Quality website" className="h-full w-full object-cover" width="600" height="480" loading="lazy" /></div>
                <figcaption className="px-4 py-3 text-sm leading-6 text-[var(--sutra-muted)]">Massage therapy room shown in the original gallery.</figcaption>
              </figure>
              <figure className="overflow-hidden border border-[var(--sutra-border)] bg-[var(--sutra-porcelain)]">
                <div className="aspect-[5/4] overflow-hidden bg-[#e5e8df]"><img src="https://lifequality.org.in/images/4img.jpg" alt="Person relaxing during a traditional wellness session" className="h-full w-full object-cover" width="600" height="480" loading="lazy" /></div>
                <figcaption className="px-4 py-3 text-sm leading-6 text-[var(--sutra-muted)]">Person relaxing during a traditional wellness session.</figcaption>
              </figure>
            </div>
          </div>
        </Container>
      </section>

      <section className="bg-white">
        <Container>
          <div className="py-12 sm:py-16 lg:py-20">
            <div className="max-w-2xl">
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--sutra-teal)]">Common questions</p>
              <h2 className="mt-4 font-serif text-3xl leading-tight tracking-[-0.03em] sm:text-4xl">Before you decide</h2>
            </div>
            <div className="mt-6 max-w-4xl">          <details className="group border-b border-[var(--sutra-border)] py-5">
            <summary className="cursor-pointer list-none pr-8 text-base font-semibold text-[var(--sutra-ink)] marker:content-none">Does Shirodhara treat a medical condition?<span className="float-right text-[var(--sutra-teal)] transition-transform group-open:rotate-45">+</span></summary>
            <p className="mt-3 max-w-3xl text-sm leading-7 text-[var(--sutra-muted)]">This page describes a traditional wellness practice, not a proven treatment for a specific condition. Seek advice from a qualified healthcare professional for diagnosis and treatment.</p>
          </details>
          <details className="group border-b border-[var(--sutra-border)] py-5">
            <summary className="cursor-pointer list-none pr-8 text-base font-semibold text-[var(--sutra-ink)] marker:content-none">Can everyone receive Shirodhara?<span className="float-right text-[var(--sutra-teal)] transition-transform group-open:rotate-45">+</span></summary>
            <p className="mt-3 max-w-3xl text-sm leading-7 text-[var(--sutra-muted)]">Suitability depends on individual circumstances and the materials and method used. Discuss your health history and concerns with the provider before booking.</p>
          </details></div>
            <p className="mt-8 max-w-3xl text-sm leading-7 text-[var(--sutra-muted)]">This information describes traditional wellness practices and is not a diagnosis or treatment recommendation. Discuss individual health concerns with a qualified healthcare professional.</p>
            <Link href="/book-appointment" className="mt-6 inline-flex min-h-12 items-center justify-center bg-[#173B36] px-6 py-3 text-sm font-bold text-white hover:bg-[#24554d]">Contact Sutra Health <span className="ml-2" aria-hidden="true">↗</span></Link>
          </div>
        </Container>
      </section>
    </main>
  );
}
